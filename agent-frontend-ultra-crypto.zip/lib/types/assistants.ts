export interface Assistant {
  id: string;
  name: string;
  status: string;
  phoneNumber?: string;
  voice: string;
  calls: number;
}
  
  